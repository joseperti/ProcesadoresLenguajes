
import java.util.ArrayList;


public class Simbolo {
	public String op;
	public Character tipoOperador;
	public String tipoDato;
	public ArrayList<String> arrayVariables;
	public String auxiliar = "";
        
	public static final Character T_OP_LOG = 'l';
	public static final Character T_OP_ARIT = 'a';
	public static final Character T_OP_COMP = 'c';
	public static final String T_DATO_INTEGER = "Integer";
	public static final String T_DATO_REAL = "Real";
	public static final String T_DATO_CHARACTER = "Character";
        
        
	
}
