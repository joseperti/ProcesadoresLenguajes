
import java.util.ArrayList;


public class Simbolo {
	public String op;
	public Character tipoOperador;
	public String tipoDato;
	public ArrayList<String> arrayVariables;
	public String auxiliar = "";
        
	public static final Character T_OP_LOG = 'l';
	public static final Character T_OP_ARIT = 'a';
	public static final Character T_OP_COMP = 'c';
	public static final String T_DATO_INTEGER = "<span class='palres'> INTEGER </span>";
	public static final String T_DATO_REAL = "<span class='palres'> REAL </span>";
	public static final String T_DATO_CHARACTER = "<span class='palres'> CHARACTER </span>";
        
        
	
}
